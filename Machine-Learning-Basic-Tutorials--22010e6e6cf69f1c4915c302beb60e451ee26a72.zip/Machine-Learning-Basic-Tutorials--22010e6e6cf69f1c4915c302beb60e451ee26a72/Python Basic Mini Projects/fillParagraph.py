name = input("Name: ")
age = input("Age: ")
interest = input("Interest: ")
adj = input("Adjective: ")

paragraph = f"My name is {name}, and I am {age} years old. I like to do {interest} \
because it is very {adj}."

print(paragraph)
input()
